<!DOCTYPE HTML>
<html>  
<body>

<form action="major_edit_save.php" method="post">
ID: <input type="number" class="name" name='id'placeholder="ID"><br/>
Ngành Học: <input type="text" class="name" name='name' placeholder="Ten nganh">
<input type="submit">
</form>

</body>
</html>
