<!DOCTYPE HTML>
<html>  

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM major";



$result = $conn->query($sql);

// foreach($result->fetch_all() as $row){
//   echo $row[1];
// }
?>

<body>
<form action="luu.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<label for="cars">Chuyên ngành:</label>
<select id="cars" name="major">
  <?php
  foreach($result->fetch_all() as $row){
    echo "<option value=".$row[0].">".$row[1]."</option>";
  }
  ?>
  
</select><br/>

Birthday: <input type="date" name="birth"><br>

<input type="submit">

</form>

</body>
</html>

